# YASTRIA — GitHub Pages Ready

## Upload
Upload everything in this folder to the ROOT of a GitHub repository.

Structure:
- index.html
- assets/
- css/
- js/

Then enable GitHub Pages:
Settings → Pages → Deploy from a branch → main → / (root) → Save

The live URL will be:
https://YOUR-GITHUB-USERNAME.github.io/yastria/

## Notes
- WhatsApp ordering uses +91 8983931395 as configured in the website.
- Product prices in js/products.js are starter values; edit them before publishing if needed.
