
const WA = "918983931395";
let cart = JSON.parse(localStorage.getItem("yastria_cart") || "[]");

const $ = s => document.querySelector(s);
const money = n => "₹" + Number(n).toLocaleString("en-IN");

function save(){ localStorage.setItem("yastria_cart", JSON.stringify(cart)); renderCart(); }
function addToCart(id){
  const p=PRODUCTS.find(x=>x.id===id); if(!p) return;
  const old=cart.find(x=>x.id===id);
  if(old) old.qty++; else cart.push({...p,qty:1});
  save(); openCart();
}
function removeFromCart(id){ cart=cart.filter(x=>x.id!==id); save(); }
function renderCart(){
  const box=$("#cartItems"), count=$("#cartCount"), total=$("#cartTotal");
  if(!box) return;
  const qty=cart.reduce((a,x)=>a+x.qty,0), sum=cart.reduce((a,x)=>a+x.price*x.qty,0);
  count.textContent=qty; total.textContent=money(sum);
  box.innerHTML=cart.length ? cart.map(x=>`
    <div style="display:flex;gap:12px;padding:12px 0;border-bottom:1px solid rgba(23,19,18,.1)">
      <img src="${x.image}" style="width:70px;height:70px;object-fit:cover;border-radius:12px">
      <div style="flex:1"><strong>${x.name}</strong><div style="font-size:12px;color:#766d66">Qty ${x.qty} · ${money(x.price*x.qty)}</div>
      <button onclick="removeFromCart('${x.id}')" style="border:0;background:none;padding:5px 0;cursor:pointer;font-size:11px">Remove</button></div>
    </div>`).join("") : '<p style="color:#766d66">Your bag is empty. Explore the collection and add something beautiful.</p>';
}
function productCard(p){
 return `<article class="product-card">
   <img src="${p.image}" alt="${p.name}" loading="lazy">
   <div class="product-info">
    <div style="font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:#9b7442">${p.category}</div>
    <h3>${p.name}</h3><p>${p.description}</p>
    <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:12px">
      <span class="price">${money(p.price)}</span>
      <button class="btn btn-gold" style="min-height:38px;padding:0 14px" onclick="addToCart('${p.id}')">Add to Bag</button>
    </div>
   </div>
 </article>`;
}
function renderProducts(filter="All", query=""){
 const grid=$("#productGrid"); if(!grid) return;
 const q=query.trim().toLowerCase();
 const list=PRODUCTS.filter(p=>(filter==="All"||p.category===filter)&&(!q||[p.name,p.category,p.description].join(" ").toLowerCase().includes(q)));
 grid.innerHTML=list.length?list.map(productCard).join(""):"<p style='grid-column:1/-1;color:#766d66'>No products found.</p>";
}
function openCart(){ $("#cartDrawer")?.classList.add("open"); $("#drawerBackdrop")?.classList.add("active"); renderCart(); }
function closeCart(){ $("#cartDrawer")?.classList.remove("open"); $("#drawerBackdrop")?.classList.remove("active"); }
function whatsappOrder(){
 const lines=cart.map(x=>`• ${x.name} × ${x.qty} — ${money(x.price*x.qty)}`).join("\n");
 const total=cart.reduce((a,x)=>a+x.price*x.qty,0);
 const msg=cart.length?`Hello YASTRIA! I'd like to order:\n${lines}\n\nSubtotal: ${money(total)}\nPlease confirm availability and delivery details.`:"Hello YASTRIA! I'd like help choosing a gift.";
 window.open(`https://wa.me/${WA}?text=${encodeURIComponent(msg)}`,"_blank");
}
document.addEventListener("DOMContentLoaded",()=>{
 renderProducts(); renderCart();
 $("#cartBtn")?.addEventListener("click",openCart); $("#closeCart")?.addEventListener("click",closeCart); $("#drawerBackdrop")?.addEventListener("click",closeCart);
 $("#continueBtn")?.addEventListener("click",closeCart); $("#checkoutBtn")?.addEventListener("click",whatsappOrder);
 $("#menuBtn")?.addEventListener("click",()=>$("#nav")?.classList.toggle("open"));
 document.querySelectorAll(".filter-btn").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".filter-btn").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderProducts(b.dataset.filter);}));
 document.querySelectorAll(".collection-card").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".filter-btn").forEach(x=>x.classList.toggle("active",x.dataset.filter===b.dataset.category));renderProducts(b.dataset.category);document.querySelector("#shop")?.scrollIntoView({behavior:"smooth"});}));
 $("#searchBtn")?.addEventListener("click",()=>{$("#searchOverlay")?.classList.add("active");$("#searchInput")?.focus();});
 $("#closeSearch")?.addEventListener("click",()=>$("#searchOverlay")?.classList.remove("active"));
 $("#searchInput")?.addEventListener("input",e=>renderProducts("All",e.target.value));
 document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>$("#nav")?.classList.remove("open")));
});
