
const PRODUCTS = [
  {id:"m1", name:"Floral Mangalsutra", category:"Mangalsutras", price:899, image:"assets/YASTRIA_Mangalsutra_Floral.jpg", description:"A refined handmade mangalsutra with delicate floral detailing."},
  {id:"m2", name:"Lotus Mangalsutra", category:"Mangalsutras", price:999, image:"assets/YASTRIA_Mangalsutra_Lotus.jpg", description:"Elegant lotus-inspired detailing for a timeless look."},
  {id:"m3", name:"Tassel Mangalsutra", category:"Mangalsutras", price:1099, image:"assets/YASTRIA_Mangalsutra_Tassel.jpg", description:"A graceful handmade design with a distinctive tassel finish."},
  {id:"m4", name:"Floral Mangalsutra Set", category:"Mangalsutras", price:1299, image:"assets/YASTRIA_Mangalsutra_FloralSet.jpg", description:"A coordinated floral design, presented as a beautiful gift."},
  {id:"w1", name:"Kashmiri Watch", category:"Kashmiri Watches", price:1499, image:"assets/YASTRIA_Kashmiri_Watch.jpg", description:"A statement Kashmiri-inspired watch selected for YASTRIA."},
  {id:"g1", name:"Signature Gift Hamper", category:"Gift Hampers", price:1499, image:"assets/YASTRIA_Mangalsutra_FloralSet.jpg", description:"A curated gift concept; message us to customise the contents."},
  {id:"p1", name:"Personalised Gift", category:"Personalised Gifts", price:999, image:"assets/YASTRIA_Mangalsutra_Lotus.jpg", description:"Tell us the occasion and we will help create a personalised gift."}
];
